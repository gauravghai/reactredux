import { combineReducers } from "redux";
import test from "./test.reducer";

export default combineReducers({
  test,
});
