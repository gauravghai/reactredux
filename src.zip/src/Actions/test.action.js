export const incNumber = () => ({
    type: "INC",
});

export const decNumber = () => ({
    type: "DEC"
});